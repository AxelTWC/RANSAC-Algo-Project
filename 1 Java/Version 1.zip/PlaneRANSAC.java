import java.io.FileWriter;
import java.io.IOException;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class PlaneRANSAC {
    PointCloud pointCloudPlaneRANSAC;
    double epsilonValue;
    Plane3D plane3DPlaneRANSAC;
    double support; 
    Point3D point1;
    Point3D point2;
    Point3D point3;
    public PlaneRANSAC(PointCloud pc){
        boolean flag = true;
        this.pointCloudPlaneRANSAC = pc; 
        this.support = 0; 
        Point3D point1 = pointCloudPlaneRANSAC.getPoint();
        Point3D point2 = pointCloudPlaneRANSAC.getPoint();
        Point3D point3 = pointCloudPlaneRANSAC.getPoint();
        while(flag){
            if(point1.equals(point3) || point2.equals(point3) || point1.equals(point2) ){
                point1 = pointCloudPlaneRANSAC.getPoint();
                point2 = pointCloudPlaneRANSAC.getPoint();
                point3 = pointCloudPlaneRANSAC.getPoint();
                flag = true;
            }
            else{
                flag = false;
            }
        }
        this.point1 = point1;
        this.point2 = point2;
        this.point3 = point3;
        Plane3D planeTestPlane3D = new Plane3D(point1,point2,point3);
        this.plane3DPlaneRANSAC = planeTestPlane3D;
    }
    public void setEps(double eps){
        this.epsilonValue = eps;
    }
    public double getEps(){
        return epsilonValue;
    }
    public int getNumberOfIterations(double confidence, double percentageOfPointsOnPlane){
        double temp = Math.ceil(Math.log(1-confidence)/Math.log(1-Math.pow(percentageOfPointsOnPlane, 3)));
        return (int) temp;
        }
    public void run(int numberOfIterations, String filename){
        int countPoints = 0;
        int countSize = 0;
        List<Point3D> dominantPlane = new ArrayList<Point3D>();
        List<Point3D> dominantPlaneAllPoints = new ArrayList<Point3D>();
        for(int threeMostDominantPlanes = 1; threeMostDominantPlanes < 4; threeMostDominantPlanes++){
            System.out.println("RUN: " + threeMostDominantPlanes);
            System.out.println("__________________________________________________________");
            for(int j = 0; j < numberOfIterations; j++){
                PlaneRANSAC tempPlane = new PlaneRANSAC(pointCloudPlaneRANSAC);
                Iterator<Point3D> iteratorTemp = pointCloudPlaneRANSAC.iterator();
                while(iteratorTemp.hasNext()){
                    Point3D tempPoint =  iteratorTemp.next();
                    double tempDistance = tempPlane.plane3DPlaneRANSAC.getDistance(tempPoint);
                    countSize++;
                    if(tempDistance < epsilonValue){
                        countPoints++;
                    }
                }
                System.out.println("Point 1: " + tempPlane.point1);
                System.out.println("Point 2: " + tempPlane.point2);
                System.out.println("Point 3: " + tempPlane.point3);
                System.out.println("Plane: " + tempPlane.plane3DPlaneRANSAC.toString());
                System.out.println("Points: " + countPoints);
                System.out.println("Size: " + countSize);
                System.out.println("==========================================================");
                countSize = 0;
                if(countPoints > support){
                    dominantPlane.clear();
                    support = countPoints;
                    dominantPlane.add(tempPlane.point1);
                    dominantPlane.add(tempPlane.point2);
                    dominantPlane.add(tempPlane.point3);
                }
            }
            dominantPlaneAllPoints.add(dominantPlane.get(0));
            dominantPlaneAllPoints.add(dominantPlane.get(1));
            dominantPlaneAllPoints.add(dominantPlane.get(2));

            try {
            String replaceIndexForFile = String.valueOf(threeMostDominantPlanes);
            char charReplaceIndexForFile = replaceIndexForFile.charAt(0);
            String tempFileName = filename;
            tempFileName = tempFileName.replace('X', charReplaceIndexForFile);
            String stringFileName = tempFileName;
            FileWriter dominantPlanePointFile = new FileWriter(stringFileName);
            dominantPlanePointFile.write("x y z");
            dominantPlanePointFile.write("\n");
            dominantPlanePointFile.write(dominantPlane.get(0).getX() + " " + dominantPlane.get(0).getY() + " " + dominantPlane.get(0).getZ());
            dominantPlanePointFile.write("\n");
            dominantPlanePointFile.write(dominantPlane.get(1).getX() + " " + dominantPlane.get(1).getY() + " " + dominantPlane.get(1).getZ());
            dominantPlanePointFile.write("\n");
            dominantPlanePointFile.write(dominantPlane.get(2).getX() + " " + dominantPlane.get(2).getY() + " " + dominantPlane.get(2).getZ());
            dominantPlanePointFile.close();
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
              }

            dominantPlane.clear();
            System.out.println("Current Support: " + support);
            System.out.println("==========================================================");
        }
        try { //PointCloudx_p0.xyz
            String tempFileName = filename;
            tempFileName = tempFileName.replace('X', '0');
            String stringFileName = tempFileName;
            FileWriter dominantPlanePointFile = new FileWriter(stringFileName);
            dominantPlanePointFile.write("x y z");
            dominantPlanePointFile.write("\n");
            Iterator<Point3D> iteratorForp0 = pointCloudPlaneRANSAC.iterator();
            while(iteratorForp0.hasNext()){
                Point3D tempPoint =  iteratorForp0.next();
                if(!dominantPlaneAllPoints.contains(tempPoint)){
                    dominantPlanePointFile.write(tempPoint.getX() + " " + tempPoint.getY() + " " + tempPoint.getZ());
                    dominantPlanePointFile.write("\n");
                }
            }
            dominantPlanePointFile.close();
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
              }
    }
    public static void main(String[] args){ //Test function
        PointCloud pc1 = new PointCloud("PointCloud1.xyz"); 
        PlaneRANSAC testPlane1 = new PlaneRANSAC(pc1);
        testPlane1.setEps(0.02);
        testPlane1.run(3,"PointCloud1_pX.xyz");

        PointCloud pc2 = new PointCloud("PointCloud2.xyz"); 
        PlaneRANSAC testPlane2 = new PlaneRANSAC(pc2);
        testPlane2.setEps(0.04);
        testPlane2.run(46,"PointCloud2_pX.xyz");

        PointCloud pc3 = new PointCloud("PointCloud3.xyz"); 
        PlaneRANSAC testPlane3 = new PlaneRANSAC(pc3);
        testPlane3.setEps(0.006);
        testPlane3.run(50,"PointCloud3_pX.xyz");

    }
}
